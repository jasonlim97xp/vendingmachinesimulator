/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vendingmachine;

import java.awt.Color;
import javax.swing.event.DocumentListener;
import javax.swing.event.DocumentEvent;

/**
 *
 * @author Brandon-PC
 */
public class vmMachineryCP extends javax.swing.JFrame {

 

    /**
     * Creates new form maintainer
     * @param runtime
     */
    public vmMachineryCP(engine runtime) {
        initComponents();
        this.runtime = runtime ;
        BD1Text.setText(Integer.toString(runtime.quantity[0]));
        BD2Text.setText(Integer.toString(runtime.quantity[1]));
        BD3Text.setText(Integer.toString(runtime.quantity[2]));
        BD4Text.setText(Integer.toString(runtime.quantity[3]));
        BD5Text.setText(Integer.toString(runtime.quantity[4]));
        BD6Text.setText(Integer.toString(runtime.quantity[5]));
        BD7Text.setText(Integer.toString(runtime.quantity[6]));
        BD8Text.setText(Integer.toString(runtime.quantity[7]));
        BD9Text.setText(Integer.toString(runtime.quantity[8]));
        BD10Text.setText(Integer.toString(runtime.quantity[9]));
        Coin10Label.setText(Integer.toString(runtime.coin10));
        Coin20Label.setText(Integer.toString(runtime.coin20));
        Coin50Label.setText(Integer.toString(runtime.coin50));
        Coin100Label.setText(Integer.toString(runtime.coin100));
        
       
    BD1Text.getDocument().addDocumentListener(new DocumentListener(){
        @Override
            public void insertUpdate(DocumentEvent e){
                Status();
            }
            
            @Override
            public void removeUpdate(DocumentEvent e){
                Status();
            }
            
            @Override
            public void changedUpdate(DocumentEvent e){
                Status();
            }
            
    public void Status(){
        int input = 0;
        if("".equals((String) BD1Text.getText())) 
                    input=0;
        else
            input= Integer.parseInt((String) BD1Text.getText());
            runtime.setQuantity(0,input);
    }
    
});
    BD2Text.getDocument().addDocumentListener(new DocumentListener(){
        @Override
            public void insertUpdate(DocumentEvent e){
                Status();
            }
            
            @Override
            public void removeUpdate(DocumentEvent e){
                Status();
            }
            
            @Override
            public void changedUpdate(DocumentEvent e){
                Status();
            }
            
    public void Status(){
        int input;
        if("".equals((String) BD2Text.getText())) 
                    input=0;
                else
                    input= Integer.parseInt((String) BD2Text.getText());
                    runtime.setQuantity(1,input);
    }
    
});
    BD3Text.getDocument().addDocumentListener(new DocumentListener(){
        @Override
            public void insertUpdate(DocumentEvent e){
                Status();
            }
            
            @Override
            public void removeUpdate(DocumentEvent e){
                Status();
            }
            
            @Override
            public void changedUpdate(DocumentEvent e){
                Status();
            }
            
    public void Status(){
        int input;
        if("".equals((String) BD3Text.getText())) 
                    input=0;
                else
                    input= Integer.parseInt((String) BD3Text.getText());
                    runtime.setQuantity(2,input);
    }
    
});
     BD4Text.getDocument().addDocumentListener(new DocumentListener(){
        @Override
            public void insertUpdate(DocumentEvent e){
                Status();
            }
            
            @Override
            public void removeUpdate(DocumentEvent e){
                Status();
            }
            
            @Override
            public void changedUpdate(DocumentEvent e){
                Status();
            }
            
    public void Status(){
        int input;
        if("".equals((String) BD4Text.getText())) 
                    input=0;
                else
                    input= Integer.parseInt((String) BD4Text.getText());
                    runtime.setQuantity(3,input);
    }
    
}); 
     BD5Text.getDocument().addDocumentListener(new DocumentListener(){
        @Override
            public void insertUpdate(DocumentEvent e){
                Status();
            }
            
            @Override
            public void removeUpdate(DocumentEvent e){
                Status();
            }
            
            @Override
            public void changedUpdate(DocumentEvent e){
                Status();
            }
            
    public void Status(){
        int input;
        if("".equals((String) BD5Text.getText())) 
                    input=0;
                else
                    input= Integer.parseInt((String) BD5Text.getText());
                    runtime.setQuantity(4,input);
    }
    
});

     BD6Text.getDocument().addDocumentListener(new DocumentListener(){
        @Override
            public void insertUpdate(DocumentEvent e){
                Status();
            }
            
            @Override
            public void removeUpdate(DocumentEvent e){
                Status();
            }
            
            @Override
            public void changedUpdate(DocumentEvent e){
                Status();
            }
            
    public void Status(){
        int input;
        if("".equals((String) BD6Text.getText())) 
                    input=0;
                else
                    input= Integer.parseInt((String) BD6Text.getText());
                    runtime.setQuantity(5,input);
    }
    
});
    BD7Text.getDocument().addDocumentListener(new DocumentListener(){
            @Override
                public void insertUpdate(DocumentEvent e){
                    Status();
                }

                @Override
                public void removeUpdate(DocumentEvent e){
                    Status();
                }

                @Override
                public void changedUpdate(DocumentEvent e){
                    Status();
                }

        public void Status(){
            int input;
            if("".equals((String) BD7Text.getText())) 
                        input=0;
                    else
                        input= Integer.parseInt((String) BD7Text.getText());
                        runtime.setQuantity(6,input);
        }

    });
    BD8Text.getDocument().addDocumentListener(new DocumentListener(){
        @Override
            public void insertUpdate(DocumentEvent e){
                Status();
            }
            
            @Override
            public void removeUpdate(DocumentEvent e){
                Status();
            }
            
            @Override
            public void changedUpdate(DocumentEvent e){
                Status();
            }
            
    public void Status(){
        int input;
        if("".equals((String) BD8Text.getText())) 
                    input=0;
                else
                    input= Integer.parseInt((String) BD8Text.getText());
                    runtime.setQuantity(7,input);
    }
    
});
    BD9Text.getDocument().addDocumentListener(new DocumentListener(){
        @Override
            public void insertUpdate(DocumentEvent e){
                Status();
            }
            
            @Override
            public void removeUpdate(DocumentEvent e){
                Status();
            }
            
            @Override
            public void changedUpdate(DocumentEvent e){
                Status();
            }
            
    public void Status(){
        int input;
        if("".equals((String) BD9Text.getText())) 
                    input=0;
                else
                    input= Integer.parseInt((String) BD9Text.getText());
                    runtime.setQuantity(8,input);
    }
    
});
    BD10Text.getDocument().addDocumentListener(new DocumentListener(){
        @Override
            public void insertUpdate(DocumentEvent e){
                Status();
            }
            
            @Override
            public void removeUpdate(DocumentEvent e){
                Status();
            }
            
            @Override
            public void changedUpdate(DocumentEvent e){
                Status();
            }
            
    public void Status(){
        int input;
        if("".equals((String) BD10Text.getText())) 
                    input=0;
                else
                    input= Integer.parseInt((String) BD10Text.getText());
                    runtime.setQuantity(9,input);
    }
    
});
    
    if(runtime.input.equals(runtime.getPassword())){
        UnlockedLabel.setForeground(Color.green);
        LockedLabel.setForeground(Color.black);
    }
    else{
        UnlockedLabel.setForeground(Color.black);
        LockedLabel.setForeground(Color.green);
    }
}



    
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel6 = new javax.swing.JPanel();
        MSCPanel = new javax.swing.JPanel();
        MSCTitle = new javax.swing.JLabel();
        PanelPart = new javax.swing.JPanel();
        DisplayBValue = new javax.swing.JLabel();
        DisplayCValue = new javax.swing.JLabel();
        CoinPanel = new javax.swing.JPanel();
        N10Coin = new javax.swing.JLabel();
        Coin10Label = new javax.swing.JLabel();
        N20Coin = new javax.swing.JLabel();
        Coin20Label = new javax.swing.JLabel();
        N50Coin = new javax.swing.JLabel();
        Coin50Label = new javax.swing.JLabel();
        N100Coin = new javax.swing.JLabel();
        Coin100Label = new javax.swing.JLabel();
        StatusPanel = new javax.swing.JPanel();
        StatusLabel = new javax.swing.JLabel();
        LockedLabel = new javax.swing.JLabel();
        UnlockedLabel = new javax.swing.JLabel();
        Status2Label = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        BrandPanel = new javax.swing.JPanel();
        B1Panel = new javax.swing.JLabel();
        BD1Text = new javax.swing.JTextField();
        B2Panel = new javax.swing.JLabel();
        BD2Text = new javax.swing.JTextField();
        B3Panel = new javax.swing.JLabel();
        BD3Text = new javax.swing.JTextField();
        B4Panel = new javax.swing.JLabel();
        BD4Text = new javax.swing.JTextField();
        B5Panel = new javax.swing.JLabel();
        BD5Text = new javax.swing.JTextField();
        B6Panel = new javax.swing.JLabel();
        BD6Text = new javax.swing.JTextField();
        B7Panel = new javax.swing.JLabel();
        BD7Text = new javax.swing.JTextField();
        B8Panel = new javax.swing.JLabel();
        BD8Text = new javax.swing.JTextField();
        B9Panel = new javax.swing.JLabel();
        BD9Text = new javax.swing.JTextField();
        B10Panel = new javax.swing.JLabel();
        BD10Text = new javax.swing.JTextField();

        setLayout(new java.awt.BorderLayout());

        MSCPanel.setLayout(new java.awt.BorderLayout());

        MSCTitle.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        MSCTitle.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        MSCTitle.setText("MACHINERY SIMULATION CONTROL PANEL");
        MSCTitle.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        MSCPanel.add(MSCTitle, java.awt.BorderLayout.PAGE_START);

        DisplayBValue.setText("DISPLAY/ENTER NEW VALUE");

        DisplayCValue.setText("DISPLAY/ENTER NEW VALUE");

        CoinPanel.setLayout(new java.awt.GridLayout(4, 2));

        N10Coin.setText("NUMBER OF 10c COINS ");
        CoinPanel.add(N10Coin);
        CoinPanel.add(Coin10Label);

        N20Coin.setText("NUMBER OF 20c COINS ");
        CoinPanel.add(N20Coin);
        CoinPanel.add(Coin20Label);

        N50Coin.setText("NUMBER OF 50c COINS");
        CoinPanel.add(N50Coin);
        CoinPanel.add(Coin50Label);

        N100Coin.setText("NUMBER OF 100c COINS");
        CoinPanel.add(N100Coin);
        CoinPanel.add(Coin100Label);

        StatusPanel.setLayout(new java.awt.GridLayout(2, 3));

        StatusLabel.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        StatusLabel.setText("STATUS OF VENDING MACHINE");
        StatusPanel.add(StatusLabel);

        LockedLabel.setText("LOCKED ");
        StatusPanel.add(LockedLabel);

        UnlockedLabel.setText("UNLOCKED");
        StatusPanel.add(UnlockedLabel);

        Status2Label.setText("DOOR LOCK(change status if req)");
        StatusPanel.add(Status2Label);
        StatusPanel.add(jLabel13);

        BrandPanel.setLayout(new java.awt.GridLayout(10, 2));

        B1Panel.setText("NUMBER OF DRINKS CANS BRAND 1");
        BrandPanel.add(B1Panel);

        BD1Text.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BD1TextActionPerformed(evt);
            }
        });
        BrandPanel.add(BD1Text);

        B2Panel.setText("NUMBER OF DRINKS CANS BRAND 2");
        BrandPanel.add(B2Panel);

        BD2Text.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BD2TextActionPerformed(evt);
            }
        });
        BrandPanel.add(BD2Text);

        B3Panel.setText("NUMBER OF DRINKS CANS BRAND 3");
        BrandPanel.add(B3Panel);
        BrandPanel.add(BD3Text);

        B4Panel.setText("NUMBER OF DRINKS CANS BRAND 4");
        BrandPanel.add(B4Panel);
        BrandPanel.add(BD4Text);

        B5Panel.setText("NUMBER OF DRINKS CANS BRAND 5");
        BrandPanel.add(B5Panel);
        BrandPanel.add(BD5Text);

        B6Panel.setText("NUMBER OF DRINKS CANS BRAND 6");
        BrandPanel.add(B6Panel);
        BrandPanel.add(BD6Text);

        B7Panel.setText("NUMBER OF DRINKS CANS BRAND 7");
        BrandPanel.add(B7Panel);
        BrandPanel.add(BD7Text);

        B8Panel.setText("NUMBER OF DRINKS CANS BRAND 8");
        BrandPanel.add(B8Panel);
        BrandPanel.add(BD8Text);

        B9Panel.setText("NUMBER OF DRINKS CANS BRAND 9");
        BrandPanel.add(B9Panel);
        BrandPanel.add(BD9Text);

        B10Panel.setText("NUMBER OF DRINKS CANS BRAND 10");
        BrandPanel.add(B10Panel);

        BD10Text.setMinimumSize(new java.awt.Dimension(8, 20));
        BD10Text.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BD10TextActionPerformed(evt);
            }
        });
        BrandPanel.add(BD10Text);

        javax.swing.GroupLayout PanelPartLayout = new javax.swing.GroupLayout(PanelPart);
        PanelPart.setLayout(PanelPartLayout);
        PanelPartLayout.setHorizontalGroup(
            PanelPartLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelPartLayout.createSequentialGroup()
                .addComponent(CoinPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(106, 106, 106))
            .addComponent(StatusPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelPartLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(PanelPartLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(DisplayCValue, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(DisplayBValue, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)))
            .addComponent(BrandPanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        PanelPartLayout.setVerticalGroup(
            PanelPartLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelPartLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(DisplayBValue)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(BrandPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(DisplayCValue)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(CoinPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(StatusPanel, javax.swing.GroupLayout.DEFAULT_SIZE, 119, Short.MAX_VALUE)
                .addContainerGap())
        );

        MSCPanel.add(PanelPart, java.awt.BorderLayout.CENTER);

        add(MSCPanel, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents

    private void BD2TextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BD2TextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BD2TextActionPerformed

    private void BD10TextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BD10TextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BD10TextActionPerformed

    private void BD1TextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BD1TextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BD1TextActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel B10Panel;
    private javax.swing.JLabel B1Panel;
    private javax.swing.JLabel B2Panel;
    private javax.swing.JLabel B3Panel;
    private javax.swing.JLabel B4Panel;
    private javax.swing.JLabel B5Panel;
    private javax.swing.JLabel B6Panel;
    private javax.swing.JLabel B7Panel;
    private javax.swing.JLabel B8Panel;
    private javax.swing.JLabel B9Panel;
    private javax.swing.JTextField BD10Text;
    private javax.swing.JTextField BD1Text;
    private javax.swing.JTextField BD2Text;
    private javax.swing.JTextField BD3Text;
    private javax.swing.JTextField BD4Text;
    private javax.swing.JTextField BD5Text;
    private javax.swing.JTextField BD6Text;
    private javax.swing.JTextField BD7Text;
    private javax.swing.JTextField BD8Text;
    private javax.swing.JTextField BD9Text;
    private javax.swing.JPanel BrandPanel;
    private javax.swing.JLabel Coin100Label;
    private javax.swing.JLabel Coin10Label;
    private javax.swing.JLabel Coin20Label;
    private javax.swing.JLabel Coin50Label;
    private javax.swing.JPanel CoinPanel;
    private javax.swing.JLabel DisplayBValue;
    private javax.swing.JLabel DisplayCValue;
    private javax.swing.JLabel LockedLabel;
    private javax.swing.JPanel MSCPanel;
    private javax.swing.JLabel MSCTitle;
    private javax.swing.JLabel N100Coin;
    private javax.swing.JLabel N10Coin;
    private javax.swing.JLabel N20Coin;
    private javax.swing.JLabel N50Coin;
    private javax.swing.JPanel PanelPart;
    private javax.swing.JLabel Status2Label;
    private javax.swing.JLabel StatusLabel;
    private javax.swing.JPanel StatusPanel;
    private javax.swing.JLabel UnlockedLabel;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JPanel jPanel6;
    // End of variables declaration//GEN-END:variables

    int input;
    engine runtime;
}
